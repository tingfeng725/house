return {
	name = "Cloudflare",
	label = _("Cloudflare"),
	resolver_url = "https://cloudflare-dns.com/dns-query",
	bootstrap_dns = "1.1.1.1,1.0.0.1"
}
