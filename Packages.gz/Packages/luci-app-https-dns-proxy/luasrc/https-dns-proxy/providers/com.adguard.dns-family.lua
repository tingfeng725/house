return {
	name = "AdGuard-Family",
	label = _("AdGuard (Family Protection)"),
	resolver_url = "https://dns-family.adguard.com/dns-query",
	bootstrap_dns = "176.103.130.132,176.103.130.134",
	help_link = "https://adguard.com/en/adguard-dns/overview.html",
	help_link_text = "AdGuard.com"
}
