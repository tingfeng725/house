return {
	name = "Google",
	label = _("Google"),
	resolver_url = "https://dns.google/dns-query",
	bootstrap_dns = "8.8.8.8,8.8.4.4",
	default = true
}
