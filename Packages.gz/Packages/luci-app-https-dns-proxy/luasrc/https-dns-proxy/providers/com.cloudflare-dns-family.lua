return {
	name = "Cloudflare for Families",
	label = _("Cloudflare for Families"),
	resolver_url = "https://family.cloudflare-dns.com/dns-query",
	bootstrap_dns = "1.1.1.3,1.0.0.3"
}
