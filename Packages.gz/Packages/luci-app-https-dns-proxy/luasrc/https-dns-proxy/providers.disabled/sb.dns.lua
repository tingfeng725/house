return {
	name = "DNS.SB",
	label = _("DNS.SB"),
	resolver_url = "https://doh.dns.sb/dns-query",
	bootstrap_dns = "185.222.222.222,185.184.222.222"
}
