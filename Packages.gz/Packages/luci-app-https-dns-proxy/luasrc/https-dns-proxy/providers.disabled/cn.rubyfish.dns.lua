return {
	name = "rubyfish.cn",
	label = _("rubyfish.cn"),
	resolver_url = "https://dns.rubyfish.cn/dns-query",
	bootstrap_dns = "118.89.110.78,47.96.179.163"
}
